# Dino-Game
 
Dinosaur Jurassic Park game for CART IGD class project between 
PaofueMMoua - programmer, lead music designer, lead map designer
KingFriday23 - lead programmer, colead map designer
Chenyawn - lead visual artist, programmer 